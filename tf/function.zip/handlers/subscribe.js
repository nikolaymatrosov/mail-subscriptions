"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.subscribe = void 0;
const ids_1 = require("../ids");
const db_1 = require("../db");
const models_1 = require("../models");
const logger_1 = require("../logger");
const ydb_sdk_1 = require("ydb-sdk");
const subscribe = async (req, res) => {
    const driver = req.apiGateway.context.driver;
    const newSub = new models_1.Subscription({
        id: (0, ids_1.generateId)(),
        ip: getIp(req),
        email: req.body.email,
        verified: false,
        createdAt: new Date(),
        verifiedAt: null,
    });
    try {
        await driver.queryClient.do({
            fn: async (session) => {
                await session.beginTransaction({ serializableReadWrite: {} });
                const subscriptions = await (0, db_1.getSubscriptionByEmail)(session, newSub.email);
                if (subscriptions.length > 0) {
                    await session.rollbackTransaction();
                    res.json({
                        message: 'Subscription already exists'
                    });
                    return;
                }
                const fromIp = await (0, db_1.listSubscriptionsByIp)(session, newSub.ip);
                if (fromIp.length > 2) {
                    await session.rollbackTransaction();
                    res.json({
                        message: 'Too many subscriptions from this IP'
                    });
                    return;
                }
                await (0, db_1.createSubscription)(session, newSub);
                await (0, db_1.insertEvent)(session, new models_1.SubscriptionCreatedEvent({
                    id: (0, ids_1.generateId)(),
                    createdAt: new Date(),
                    subscriptionId: newSub.id,
                    payload: {
                        type: 'SubscriptionCreated',
                        subscriptionId: newSub.id,
                        email: newSub.email,
                        createdAt: newSub.createdAt,
                        headers: req.headers,
                    },
                }));
                await session.commitTransaction();
            }
        });
    }
    catch (e) {
        if (e instanceof ydb_sdk_1.YdbError) {
            logger_1.logger.error("err", { stack: e.stack, message: e.message, cause: e.cause });
        }
        console.error(e);
        res.status(500).json({
            message: 'Internal Server Error'
        });
        return;
    }
    res.json({
        message: 'Subscription created'
    });
};
exports.subscribe = subscribe;
function getIp(req) {
    const ip = req.headers['x-forwarded-for'];
    if (ip === undefined) {
        return 'unknown';
    }
    return Array.isArray(ip) ? ip[0] : ip;
}
