"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validate = void 0;
const logger_1 = require("../logger");
const validate = async (req, res) => {
    logger_1.logger.info('Subscribing new user');
};
exports.validate = validate;
