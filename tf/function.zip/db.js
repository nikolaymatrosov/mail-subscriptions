"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSubscription = createSubscription;
exports.getSubscription = getSubscription;
exports.getSubscriptionByEmail = getSubscriptionByEmail;
exports.listSubscriptionsByIp = listSubscriptionsByIp;
exports.insertEvent = insertEvent;
exports.verifySubscription = verifySubscription;
exports.deleteSubscription = deleteSubscription;
const ydb_sdk_1 = require("ydb-sdk");
const models_1 = require("./models");
const logger_1 = require("./logger");
async function createSubscription(session, subscription) {
    const text = `
DECLARE $data AS List<Struct<id: Utf8, ip: Utf8, email: Utf8, verified: Bool, created_at: Timestamp, verified_at: Optional<Timestamp>>>;
INSERT INTO ${models_1.SUBSCRIPTIONS_TABLE} (id, ip, email, verified, created_at, verified_at) SELECT
    id, ip, email, verified, created_at, verified_at
FROM AS_TABLE ($data);
`;
    logger_1.logger.info('creating subscription', subscription);
    return session.execute({
        text,
        parameters: {
            $data: models_1.Subscription.asTypedCollection([subscription]),
        },
    });
}
async function getSubscription(session, id) {
    const text = `
DECLARE $id AS Utf8;
SELECT * FROM ${models_1.SUBSCRIPTIONS_TABLE} WHERE id = $id;
`;
    logger_1.logger.info('getting subscription', id);
    const { resultSets, } = await session.execute({
        text,
        parameters: {
            $id: ydb_sdk_1.TypedValues.utf8(id),
        },
    });
    return models_1.Subscription.from(resultSets);
}
async function getSubscriptionByEmail(session, email) {
    const text = `
DECLARE $email AS Utf8;
SELECT * FROM ${models_1.SUBSCRIPTIONS_TABLE} VIEW ${models_1.SUBSCRIPTIONS_TABLE}_email WHERE email = $email;
`;
    logger_1.logger.info('getting subscription by email', email);
    const { resultSets, } = await session.execute({
        text,
        parameters: {
            $email: ydb_sdk_1.TypedValues.utf8(email),
        },
    });
    return models_1.Subscription.from(resultSets);
}
async function listSubscriptionsByIp(session, ip) {
    const text = `
DECLARE $ip AS Utf8;
SELECT * FROM ${models_1.SUBSCRIPTIONS_TABLE} VIEW ${models_1.SUBSCRIPTIONS_TABLE}_ip WHERE ip = $ip;
`;
    logger_1.logger.info('listing subscriptions by ip', ip);
    const { resultSets } = await session.execute({
        text,
        parameters: {
            $ip: ydb_sdk_1.TypedValues.utf8(ip),
        },
    });
    return models_1.Subscription.from(resultSets);
}
async function insertEvent(session, event) {
    const text = `
DECLARE $data AS List<Struct<id: Utf8, created_at: Timestamp, subscription_id: Utf8, payload: JsonDocument>>;
INSERT INTO ${models_1.EVENTS_TABLE} (id, created_at, subscription_id, payload) SELECT
    id, created_at, subscription_id, payload
FROM AS_TABLE ($data);
`;
    logger_1.logger.info('inserting event', event);
    logger_1.logger.debug('$data', models_1.Event.asTypedCollection([event]));
    return session.execute({
        text,
        parameters: {
            $data: models_1.Event.asTypedCollection([event]),
        },
    });
}
async function verifySubscription(session, subscription) {
    const text = `
DECLARE $id AS Utf8;
DECLARE $verified_at AS Timestamp;
UPDATE ${models_1.SUBSCRIPTIONS_TABLE} SET verified = true, verified_at = $verified_at WHERE id = $id;
    `;
    logger_1.logger.info('updating subscription', subscription);
    return session.execute({
        text,
        parameters: {
            $id: ydb_sdk_1.TypedValues.utf8(subscription.id),
            $verified_at: ydb_sdk_1.TypedValues.timestamp(subscription.verifiedAt),
        },
    });
}
async function deleteSubscription(session, id) {
    const text = `
DECLARE $id AS Utf8;
DELETE FROM ${models_1.SUBSCRIPTIONS_TABLE} WHERE id = $id;
`;
    logger_1.logger.info('deleting subscription', id);
    return session.execute({
        text,
        parameters: {
            $id: ydb_sdk_1.TypedValues.utf8(id),
        },
    });
}
