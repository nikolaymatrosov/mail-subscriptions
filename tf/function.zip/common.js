"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateId = void 0;
exports.bodyParser = bodyParser;
// 3 seconds
const nanoid_1 = require("nanoid");
const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
exports.generateId = (0, nanoid_1.customAlphabet)(alphabet, 20);
function bodyParser(contentType, body, isBase64Encoded) {
    contentType = contentType || '';
    if (body === undefined) {
        return {};
    }
    isBase64Encoded = isBase64Encoded || false;
    if (isBase64Encoded) {
        body = Buffer.from(body, 'base64').toString('utf8');
    }
    switch (contentType) {
        case 'application/json':
            return JSON.parse(body);
        case 'application/x-www-form-urlencoded':
            return body.split('&').reduce((acc, pair) => {
                const [key, value] = pair.split('=');
                acc[key] = decodeURIComponent(value);
                return acc;
            }, {});
        default:
            return body;
    }
}
