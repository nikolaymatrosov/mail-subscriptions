"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verify = void 0;
const logger_1 = require("../../logger");
const models_1 = require("../../models");
const ids_1 = require("../../ids");
const db_1 = require("../db");
const verify = async (req, res) => {
    const driver = req.apiGateway.context.driver;
    const subscriptionId = req.params.subscriptionId;
    try {
        await driver.queryClient.do({
            fn: async (session) => {
                await session.beginTransaction({ serializableReadWrite: {} });
                const subscriptions = await (0, db_1.getSubscription)(session, subscriptionId);
                if (subscriptions.length == 0) {
                    await session.rollbackTransaction();
                    res.json({
                        message: 'Subscription not found'
                    });
                    return;
                }
                const sub = subscriptions[0];
                sub.verifiedAt = new Date();
                await (0, db_1.verifySubscription)(session, sub);
                await (0, db_1.insertEvent)(session, new models_1.SubscriptionVerifiedEvent({
                    id: (0, ids_1.generateId)(),
                    createdAt: new Date(),
                    subscriptionId: sub.id,
                    payload: {
                        type: 'SubscriptionVerified',
                        subscriptionId: sub.id,
                        verifiedAt: sub.verifiedAt,
                        headers: req.headers,
                    },
                }));
                await session.commitTransaction();
            }
        });
    }
    catch (e) {
        logger_1.logger.error('Error verifying subscription', { error: e });
        res.status(500).json({
            message: 'Internal Server Error'
        });
        return;
    }
    res.redirect('https://nikolaymatrosov.ru/');
};
exports.verify = verify;
