"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.subscribe = void 0;
const ids_1 = require("../../ids");
const db_1 = require("../db");
const models_1 = require("../../models");
const logger_1 = require("../../logger");
const ydb_sdk_1 = require("ydb-sdk");
const common_1 = require("./common");
const CAPTCHA_SECRET = process.env.CAPTCHA_SECRET || '';
const CAPTCHA_URL = 'https://smartcaptcha.yandexcloud.net/validate';
function validEmail(email) {
    const re = /^[\w\-.]+(\+[\w\-.]+)?@([\w-]+\.)+[\w-]{2,}$/;
    return re.test(email);
}
const subscribe = async (req, res) => {
    const driver = req.apiGateway.context.driver;
    const ip = (0, common_1.getIp)(req);
    const email = req.body.email;
    const token = req.body.captchaToken;
    if (!validEmail(email)) {
        res.status(400).json({
            message: 'Invalid email'
        });
        return;
    }
    if (!token) {
        res.status(400).json({
            message: 'Captcha token is required'
        });
        return;
    }
    const captcha = await validateCaptcha(token, ip);
    if (!captcha) {
        res.status(400).json({
            message: 'Captcha validation failed'
        });
        return;
    }
    const newSub = newSubscription(ip, email);
    try {
        const result = await driver.queryClient.do({
            fn: async (session) => {
                await session.beginTransaction({ serializableReadWrite: {} });
                const subscriptions = await (0, db_1.getSubscriptionByEmail)(session, newSub.email);
                if (subscriptions.length > 0) {
                    await session.rollbackTransaction();
                    return {
                        message: 'Subscription already exists'
                    };
                }
                const fromIp = await (0, db_1.listSubscriptionsByIp)(session, newSub.ip);
                if (fromIp.length > 2) {
                    await session.rollbackTransaction();
                    return {
                        message: 'Too many subscriptions from this IP'
                    };
                }
                await (0, db_1.createSubscription)(session, newSub);
                await (0, db_1.insertEvent)(session, new models_1.SubscriptionCreatedEvent({
                    id: (0, ids_1.generateId)(),
                    createdAt: new Date(),
                    subscriptionId: newSub.id,
                    payload: {
                        type: 'SubscriptionCreated',
                        subscriptionId: newSub.id,
                        email: newSub.email,
                        createdAt: newSub.createdAt,
                        headers: req.headers,
                    },
                }));
                await session.commitTransaction();
            }
        });
        if (result) {
            res.status(400).json(result);
            return;
        }
        res.json({
            message: 'Subscription created'
        });
        return;
    }
    catch (e) {
        if (e instanceof ydb_sdk_1.YdbError) {
            logger_1.logger.error('err', { stack: e.stack, message: e.message, cause: e.cause });
        }
        console.error(e);
        res.status(500).json({
            message: 'Internal Server Error'
        });
        return;
    }
};
exports.subscribe = subscribe;
function validateCaptcha(token, ip) {
    return fetch(CAPTCHA_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: captchaRequest(token, ip)
    })
        .then(res => res.json())
        .then(data => {
        logger_1.logger.info('Captcha response', { data });
        return data.status === 'ok';
    });
}
function captchaRequest(token, ip) {
    return `secret=${CAPTCHA_SECRET}&token=${token}&ip=${ip}`;
}
function newSubscription(ip, email) {
    return new models_1.Subscription({
        id: (0, ids_1.generateId)(),
        ip: ip,
        email: email,
        verified: false,
        createdAt: new Date(),
        verifiedAt: null,
    });
}
