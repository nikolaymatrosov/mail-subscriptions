"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIp = getIp;
function getIp(req) {
    const ip = req.headers['x-forwarded-for'];
    if (ip === undefined) {
        return 'unknown';
    }
    return Array.isArray(ip) ? ip[0] : ip;
}
