"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const ydb_sdk_1 = require("ydb-sdk");
const logger_1 = require("../logger");
const ses_client_1 = require("./ses-client");
const client_sesv2_1 = require("@aws-sdk/client-sesv2");
const models_1 = require("../models");
const handlebars = __importStar(require("handlebars"));
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const db_1 = require("./db");
let endpoint = process.env.YDB_ENDPOINT;
let database = process.env.YDB_DATABASE;
async function send(driver, sesClient, event) {
    const payload = extractPayload(event);
    if (payload === null) {
        return;
    }
    const verification = new models_1.Verification({
        eventId: event.key[0],
        email: payload.email,
        subscriptionId: payload.subscriptionId,
        createdAt: new Date(),
        sentAt: null,
    });
    // Use two transactions to insert verification and send email
    await driver.queryClient.do({
        fn: async (session) => {
            return (0, db_1.insertVerification)(session, verification);
        }
    });
    // If sending email fails, we will not update the sent_at field
    return driver.queryClient.do({
        fn: async (session) => {
            const input = composeEmailReq(payload.email, payload.subscriptionId);
            const sendCmd = new client_sesv2_1.SendEmailCommand(input);
            try {
                const sesMsg = await sesClient.send(sendCmd);
                logger_1.logger.info(`Email sent to ${payload.email}, messageId: ${sesMsg.MessageId}`);
                const sentAt = new Date();
                return (0, db_1.updateVerification)(session, verification.eventId, sentAt);
            }
            catch (e) {
                logger_1.logger.error(`Error sending email to ${payload.email}`, { error: e });
            }
        }
    });
}
function extractPayload(msg) {
    if (msg.newImage === undefined || msg.newImage?.payload === undefined) {
        return null;
    }
    if (msg.newImage?.payload.type !== 'SubscriptionCreated') {
        return null;
    }
    return msg.newImage?.payload;
}
const handler = async (event, context) => {
    logger_1.logger.info('Received event', { event });
    if (context.token === undefined || context.token.access_token === undefined) {
        logger_1.logger.error('Token is not provided');
        return {
            statusCode: 401,
            body: 'Unauthorized'
        };
    }
    const token = context.token?.access_token;
    const authService = new ydb_sdk_1.TokenAuthService(token);
    const driver = new ydb_sdk_1.Driver({ endpoint, database, authService, logger: logger_1.logger });
    const timeout = 3000;
    if (!await driver.ready(timeout)) {
        logger_1.logger.error(`Driver has not become ready in ${timeout}ms!`);
        return {
            statusCode: 500,
            body: 'Internal Server Error'
        };
    }
    const sesClient = (0, ses_client_1.SesClientFactory)(token);
    await send(driver, sesClient, event);
    return {
        statusCode: 200,
        body: 'OK'
    };
};
exports.handler = handler;
const rawTemplate = fs.readFileSync(path.join(__dirname, '../templates/verification-email.html'), 'utf8');
const template = handlebars.compile(rawTemplate);
function composeEmailReq(email, subscriptionId) {
    return {
        FromEmailAddress: 'verify@blog.nikolaymatrosov.ru',
        Destination: {
            ToAddresses: [email]
        },
        Content: {
            Simple: {
                Subject: {
                    Data: 'Подтвердите подписку'
                },
                Body: {
                    Text: {
                        Data: `Подтвердите подписку на новые посты в блоге https://nikolaymatrosov.ru по ссылке: https://blog.nikolaymatrosov.ru/verify/${subscriptionId}`
                    },
                    Html: {
                        Data: template({ subscriptionId })
                    }
                },
            }
        }
    };
}
