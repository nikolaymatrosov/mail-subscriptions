"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SesClientFactory = SesClientFactory;
const client_sesv2_1 = require("@aws-sdk/client-sesv2");
const protocol_http_1 = require("@smithy/protocol-http");
function SesClientFactory(token) {
    const client = new client_sesv2_1.SESv2Client({
        region: 'ru-central1',
        endpoint: 'https://postbox.cloud.yandex.net',
    });
    // eslint-disable-next-line  @typescript-eslint/no-explicit-any
    const middleware = next => {
        return async (args) => {
            if (!protocol_http_1.HttpRequest.isInstance(args.request)) {
                return next(args);
            }
            args.request.headers['X-YaCloud-SubjectToken'] = token;
            return next(args);
        };
    };
    client.middlewareStack.removeByTag('HTTP_AUTH_SCHEME');
    client.middlewareStack.removeByTag('HTTP_SIGNING');
    client.middlewareStack.addRelativeTo(middleware, {
        name: 'ycAuthMiddleware',
        tags: ['YCAUTH'],
        relation: 'after',
        toMiddleware: 'retryMiddleware',
        override: true
    });
    return client;
}
