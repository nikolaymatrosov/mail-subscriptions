"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.insertVerification = insertVerification;
exports.updateVerification = updateVerification;
const models_1 = require("../models");
const logger_1 = require("../logger");
const ydb_sdk_1 = require("ydb-sdk");
async function insertVerification(session, v) {
    const text = `
    DECLARE $data AS List<Struct<event_id: Utf8, email: Utf8, created_at: Timestamp, subscription_id: Utf8, sent_at: Optional<Timestamp>>>;
    INSERT INTO ${models_1.VERIFICATIONS_TABLE} (event_id, email, created_at, subscription_id, sent_at) SELECT
        event_id, email, created_at, subscription_id, sent_at
    FROM AS_TABLE ($data);
    `;
    logger_1.logger.info('inserting verification', v);
    logger_1.logger.info('inserting verification', { data: models_1.Verification.asTypedCollection([v]) });
    return session.execute({
        text,
        parameters: {
            $data: models_1.Verification.asTypedCollection([v]),
        },
    });
}
function updateVerification(session, eventId, sentAt) {
    const text = `
    DECLARE $event_id AS Utf8;
    DECLARE $sent_at AS Timestamp;
    UPDATE ${models_1.VERIFICATIONS_TABLE} SET sent_at = $sent_at WHERE event_id = $event_id;
    `;
    logger_1.logger.info('updating verification', { eventId, sentAt });
    return session.execute({
        text,
        parameters: {
            $event_id: ydb_sdk_1.TypedValues.utf8(eventId),
            $sent_at: ydb_sdk_1.TypedValues.timestamp(sentAt),
        },
    });
}
