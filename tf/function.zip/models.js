"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Subscription_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Verification = exports.VERIFICATIONS_TABLE = exports.UnsubscribedEvent = exports.SubscriptionVerifiedEvent = exports.SubscriptionCreatedEvent = exports.Event = exports.EVENTS_TABLE = exports.Subscription = exports.SUBSCRIPTIONS_TABLE = void 0;
const ydb_sdk_1 = require("ydb-sdk");
exports.SUBSCRIPTIONS_TABLE = 'subscriptions';
let Subscription = Subscription_1 = class Subscription extends ydb_sdk_1.TypedData {
    id;
    email;
    ip;
    createdAt;
    verified;
    verifiedAt;
    constructor(data) {
        super(data);
        this.id = data.id;
        this.email = data.email;
        this.ip = data.ip;
        this.createdAt = data.createdAt;
        this.verified = data.verified;
        this.verifiedAt = data.verifiedAt;
    }
    static async from(resultSets) {
        const res = [];
        for await (const resultSet of resultSets) {
            for await (const s of resultSet.rows) {
                res.push(new Subscription_1(s));
            }
        }
        return res;
    }
};
exports.Subscription = Subscription;
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Subscription.prototype, "id", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Subscription.prototype, "email", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Subscription.prototype, "ip", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.TIMESTAMP)
], Subscription.prototype, "createdAt", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.BOOL)
], Subscription.prototype, "verified", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.optional(ydb_sdk_1.Types.TIMESTAMP))
], Subscription.prototype, "verifiedAt", void 0);
exports.Subscription = Subscription = Subscription_1 = __decorate([
    (0, ydb_sdk_1.withTypeOptions)({ namesConversion: ydb_sdk_1.snakeToCamelCaseConversion })
], Subscription);
exports.EVENTS_TABLE = 'events';
let Event = class Event extends ydb_sdk_1.TypedData {
    id;
    createdAt;
    subscriptionId;
    payload;
    constructor(data) {
        super(data);
        this.id = data.id;
        this.subscriptionId = data.subscriptionId;
        this.createdAt = data.createdAt;
        this.payload = data.payload;
    }
    getValue(propertyKey) {
        const val = super.getValue(propertyKey);
        if (propertyKey === 'payload') {
            return {
                textValue: JSON.stringify(val.textValue),
            };
        }
        return val;
    }
};
exports.Event = Event;
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Event.prototype, "id", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.TIMESTAMP)
], Event.prototype, "createdAt", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Event.prototype, "subscriptionId", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.JSON_DOCUMENT)
], Event.prototype, "payload", void 0);
exports.Event = Event = __decorate([
    (0, ydb_sdk_1.withTypeOptions)({ namesConversion: ydb_sdk_1.snakeToCamelCaseConversion })
], Event);
class SubscriptionCreatedEvent extends Event {
    constructor(data) {
        super(data);
    }
}
exports.SubscriptionCreatedEvent = SubscriptionCreatedEvent;
class SubscriptionVerifiedEvent extends Event {
    constructor(data) {
        super(data);
    }
}
exports.SubscriptionVerifiedEvent = SubscriptionVerifiedEvent;
class UnsubscribedEvent extends Event {
    constructor(data) {
        super(data);
    }
}
exports.UnsubscribedEvent = UnsubscribedEvent;
exports.VERIFICATIONS_TABLE = 'verifications';
let Verification = class Verification extends ydb_sdk_1.TypedData {
    eventId;
    email;
    subscriptionId;
    createdAt;
    sentAt;
    constructor(data) {
        super(data);
        this.eventId = data.eventId;
        this.email = data.email;
        this.createdAt = data.createdAt;
        this.subscriptionId = data.subscriptionId;
        this.sentAt = data.sentAt;
    }
};
exports.Verification = Verification;
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Verification.prototype, "eventId", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Verification.prototype, "email", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.UTF8)
], Verification.prototype, "subscriptionId", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.TIMESTAMP)
], Verification.prototype, "createdAt", void 0);
__decorate([
    (0, ydb_sdk_1.declareType)(ydb_sdk_1.Types.optional(ydb_sdk_1.Types.TIMESTAMP))
], Verification.prototype, "sentAt", void 0);
exports.Verification = Verification = __decorate([
    (0, ydb_sdk_1.withTypeOptions)({ namesConversion: ydb_sdk_1.snakeToCamelCaseConversion })
], Verification);
