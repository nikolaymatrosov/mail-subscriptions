"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
const { combine, timestamp, json, errors } = winston_1.default.format;
exports.logger = winston_1.default.createLogger({
    level: 'debug',
    format: combine(errors({ stack: true }), timestamp(), json()),
    transports: [new winston_1.default.transports.Console()],
    levels: {
        ...winston_1.default.config.npm.levels,
        fatal: 0,
        trace: 6,
    },
});
